% =======================================================================
% Partial replication of Kilian & Murphy (2012, JEEA):
% "Why Agnostic Sign Restrictions Are Not Enough: Understanding the
%  Dynamics of Oil Market VAR Models"
%
% Same 3-variable oil-market VAR as Kilian (2009, AER), identified via
% sign restrictions at three successively tighter levels:
%
%   LEVEL 1 -- sign restrictions only
%   LEVEL 2 -- sign restrictions + supply elasticity bound
%   LEVEL 3 -- sign restrictions + supply + demand elasticity bounds
%
% Level 1 uses the native toolbox path (VARopt.ident = 'sign').
% Levels 2-3 post-filter the Level 1 accepted draws by the impact
% elasticity bounds (see Kilian & Murphy, 2012, Section 4.2), yielding
% a subset of models consistent with successively tighter constraints.
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for standalone replication use, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all
rng(42)

% Toolbox root is two levels up from this file (.../VAR-Toolbox-main)
toolboxroot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(toolboxroot, 'VAR'));
addpath(fullfile(toolboxroot, 'Figure'));
addpath(fullfile(toolboxroot, 'Stats'));
addpath(fullfile(toolboxroot, 'Utils'));
addpath(fullfile(toolboxroot, 'Auxiliary'));

cd(fileparts(mfilename('fullpath')));

% Data and results folders
datadir = fullfile(fileparts(mfilename('fullpath')), 'data');
resdir  = fullfile(fileparts(mfilename('fullpath')), 'results');
if ~exist(resdir, 'dir')
    mkdir(resdir); 
end

%% 1. LOAD AND PLOT DATA
% -----------------------------------------------------------------------
% Load Data
y = readmatrix(fullfile(datadir, 'kiliandata.txt'));
dates  = (1973+1/12:1/12:2008+8/12)'; %1973:M2-2008:M9

% Variable and shock labels
vnames = {'Oil Production', 'World REA', 'Real Oil Price'};
mnem   = {'oilprod', 'rea', 'oilprice'};
snames = {'Oil Supply Shock', 'Aggregate Demand Shock', 'Oil-Specific Demand Shock'};
IDnames  = {'Sign only', 'Sign + Supply', 'Sign + Supply + Demand'};

% Details for DatesPlot
firstdate = dates(1); % 1973M2
nticks    = 6;
[T, n]    = size(y);

% Plot
figure; 
FigSize(22, 8)
for ii = 1:n
    subplot(1, 3, ii)
    plot(y(:, ii), 'LineWidth', 2, 'Color', pantone('Blue'))
    title(vnames{ii}, 'FontSize', 12)
    DatesPlot(firstdate, T, nticks, 'm')
    set(gca, 'FontSize', 11); 
    grid on; 
    SetAxesDual(gca)
end
SaveFigure(fullfile(resdir, 'Figure_1_Data'), 2)
disp('Figure 0 (data) saved.')

%% 2. VAR CONTROLS
% -----------------------------------------------------------------------
p      = 24;   % lag length
detc   = 1;    % constant
hor    = 20;   % IRF horizon (including impact)
ndraws = 5000; % No. accepted Level 1 draws. They use 1.5 million but that takes a while. With this seed 5000 works OK. 

% Sign restriction matrix (rows = variables, columns = shocks).
%  supply   AD   oil-specific demand
SIGN = [ 1,  1,  1;   % Oil production
         1,  1, -1;   % World REA
        -1,  1,  1];  % Real oil price

%% 3. ESTIMATE VAR AND RECOVER SVAR USING SIGN RESTRICTIONS ONLY (LEVEL 1)
% ------------------------------------------------------------------------
VARopt           = VARoption;
VARopt.ident     = 'sign';   % Sign restrictions
VARopt.R         = SIGN;     % Sign restriction matrix
VARopt.sr_hor    = 1;        % Restrictions imposed on impact only
VARopt.nsteps    = hor;      % Impulse response horizon
VARopt.ndraws    = ndraws;   % Number of accepted draws
VARopt.mnem      = mnem;     % Variable mnemonics
VARopt.vnames    = vnames;   % Variable names
VARopt.inference = 1;        % Draw reduced-form parameters from the posterior
VARopt.pctg      = 68;       % 1 SD bands
VARopt.mult      = 500;      % Display draw update

VAR1 = VARmodel(y, p, detc, VARopt);
disp(['Level 1 done. Acceptance rate: ' num2str(100*VAR1.accept_rate, '%.2f') '%'])

%% 4. LEVEL 2: SIGN + SUPPLY ELASTICITY BOUND
% -----------------------------------------------------------------------
% Require supply elasticity < 0.0258
B13 = squeeze(VAR1.Ball(1,3,:));  
B33 = squeeze(VAR1.Ball(3,3,:));
B12 = squeeze(VAR1.Ball(1,2,:));  
B32 = squeeze(VAR1.Ball(3,2,:));

idx2 = (B13./B33 < 0.0258) & (B12./B32 < 0.0258);
out2 = filter_draws(VAR1, idx2, VARopt);
disp(['Level 2: ' num2str(sum(idx2)) ' / ' num2str(ndraws) ' draws satisfy supply bound.'])


%% 5. LEVEL 3: SIGN + SUPPLY + DEMAND ELASTICITY BOUNDS
% -----------------------------------------------------------------------
% Require aggregate demand elasticity > -1.5
B23 = squeeze(VAR1.Ball(2,3,:)); 
idx3 = idx2 & (B23 > -1.5);
out3 = filter_draws(VAR1, idx3, VARopt);

disp(['Level 3: ' num2str(sum(idx3)) ' / ' num2str(ndraws) ' draws satisfy both bounds.'])

%% 6. CHOLESKY BENCHMARK
% -----------------------------------------------------------------------
% Recursive ordering in Kilian (2009) for comparison
VARopt_chol           = VARoption;
VARopt_chol.ident     = 'short';
VARopt_chol.nsteps    = hor;
VARopt_chol.inference = 0;

VARc    = VARmodel(y, p, detc, VARopt_chol);
IR_chol = VARc.IR;
HD_chol = VARc.HD;
B_chol  = VARc.B;
disp('Cholesky benchmark done.')

%% 7. POST-PROCESSING: SIGN FLIP AND CUMULATION
% -----------------------------------------------------------------------
% As in Kilian (2009) we make two adjustments applied before plotting.
%   (a) Sign flip: multiply shock-1 responses by -1 (negative supply shock).
%   (b) Cumulation: oil production enters in growth rates; accumulate to
%       recover the level response for variable 1.

% Recursive model
IR_chol(:,:,1) = -IR_chol(:,:,1); % a) flip shock 1
IR_chol(:,1,:) = cumsum(IR_chol(:,1,:), 1); % b) cumulate variable 1

% Sign identified models: Loop for fewer lines of code
for f = {'IRfp', 'IRmed', 'IRinf', 'IRsup', 'IRall'}
    VAR1.(f{1})(:,:,1,:) = -VAR1.(f{1})(:,:,1,:);            % a) flip shock 1
    out2.(f{1})(:,:,1,:) = -out2.(f{1})(:,:,1,:);
    out3.(f{1})(:,:,1,:) = -out3.(f{1})(:,:,1,:);
    VAR1.(f{1})(:,1,:,:) = cumsum(VAR1.(f{1})(:,1,:,:), 1);  % b) cumulate variable 1
    out2.(f{1})(:,1,:,:) = cumsum(out2.(f{1})(:,1,:,:), 1);
    out3.(f{1})(:,1,:,:) = cumsum(out3.(f{1})(:,1,:,:), 1);
end

% HD sign flip for shock 1 only (HD accumulates level by construction; no cumsum)
out2.HDfp.shock(:,1,:) = -out2.HDfp.shock(:,1,:);
out3.HDfp.shock(:,1,:) = -out3.HDfp.shock(:,1,:);
HD_chol.shock(:,1,:)   = -HD_chol.shock(:,1,:);

%% 8. FIGURE 1: FULL IDENTIFIED SET (OIL PRICE IRFs)
% -----------------------------------------------------------------------
% Replicates Figure 1 in Kilian & Murphy (2012): for each identification
% level, every accepted draw's IRF for the real oil price overlaid (the
% full identified set), plus the Fry-Pagan representative draw and the
% Cholesky benchmark. Rows = shocks, columns = identification level.

var_oil   = 3; % Focus on oil price shock
IRall_all = {VAR1.IRall, out2.IRall, out3.IRall}; % Sign restrictions
IRfp_all  = {VAR1.IRfp,  out2.IRfp,  out3.IRfp};  % Fry-Pagan model
steps     = 0:hor-1; % Start x-axis from 0

figure; 
FigSize(22, 18)
for s = 1:3     % shock (row)
    for t = 1:3 % tier (column)
        subplot(3, 3, 3*(s-1)+t); hold on
        IRFs_sign = plot(steps, squeeze(IRall_all{t}(:,var_oil,s,:)), '-', 'Color', pantone('Fog_Dark'), 'LineWidth', 0.5);
        IRFs_fp   = plot(steps, IRfp_all{t}(:,var_oil,s), '-',  'Color',  pantone('Blue'),   'LineWidth', 2);
        IRFs_chol = plot(steps, IR_chol(:,var_oil,s),     '--', 'Color', pantone('Tomato'), 'LineWidth', 1.5);
        plot(steps([1 end]), [0 0], '-k', 'LineWidth', 0.5)
        if s == 1 
            title(IDnames{t}, 'FontSize', 12); 
        end
        if t == 1
            ylabel(snames{s});  
        end
        if s == 1 && t == 1
            legend([IRFs_sign(1), IRFs_fp, IRFs_chol], ...
                {'Identified set', 'Fry-Pagan draw', 'Recursive'}, ...
                'Location', 'southwest')
        end
        xlim(steps([1 end])); 
        set(gca, 'FontSize', 10); grid on; SetAxesDual(gca)
    end
end
SaveFigure(fullfile(resdir, 'Figure_2_IRFs'), 2)

%% 9. FIGURE 4: HISTORICAL DECOMPOSITION (Level 3 vs Cholesky)
% -----------------------------------------------------------------------
figure; 
FigSize(22, 14)
for j = 1:3
    subplot(3, 1, j); 
    plot(dates(p+1:end,:), out3.HDfp.shock(p+1:T, j, var_oil), '--', 'Color', pantone('Blue'),   'LineWidth', 1.5)
    hold on
    plot(dates(p+1:end,:), HD_chol.shock(p+1:T,   j, var_oil), '-',  'Color', pantone('Tomato'), 'LineWidth', 1.5)
    plot(dates([p+1 end]), [0 0], '-k', 'LineWidth', 0.5)
    hold off
    title(snames{j}, 'FontSize', 12)
    ylim([-100 100]); 
    xlim(dates([p+1 end]))
    if j == 1
        legend({IDnames{3}, 'Cholesky (Kilian, 2009)'}, 'Location', 'best')
    end
    set(gca, 'FontSize', 11); 
    grid on; 
    SetAxesDual(gca)
end
SaveFigure(fullfile(resdir, 'Figure_3_HD'), 2)
disp('Figure 4 (historical decomposition) saved.')

%% 10. TABLE 4: IMPACT MATRICES
% -----------------------------------------------------------------------
disp('--- Cholesky (recursive) ---');         disp(B_chol)
disp('--- Sign only (L1) ---');              disp(VAR1.Bfp)
disp('--- Sign + Supply (L2) ---');          disp(out2.Bfp)
disp('--- Sign + Supply + Demand (L3) ---'); disp(out3.Bfp)
disp('--- Kilian & Murphy (2012) replication complete ---')

%% LOCAL FUNCTIONS
% -----------------------------------------------------------------------
function out = filter_draws(VAR, idx, VARopt)
% Subset Level 1 accepted draws by a logical index and recompute all
% summary statistics (median, Fry-Pagan, percentile bands, HD).
out.Ball  = VAR.Ball(:, :, idx);             % Filter impact matrices
out.IRall = VAR.IRall(:, :, :, idx);         % Filter impulse responses

pctg_inf  = (100 - VARopt.pctg) / 2;        % Lower percentile (e.g. 16 for 68% band)
out.Bmed  = median(out.Ball, 3);             % Element-wise median across draws
aux       = sum(sum((out.Ball - out.Bmed).^2, 1), 2); % Frobenius distance to median
[~, sel]  = min(aux(:));                     % Index of draw closest to median (Fry-Pagan)
out.Bfp   = out.Ball(:, :, sel);             % Fry-Pagan impact matrix
out.IRfp  = squeeze(out.IRall(:, :, :, sel)); % Fry-Pagan impulse responses
out.IRmed = median(out.IRall, 4);            % Element-wise median IRF across draws
aux2      = prctile(out.IRall, [pctg_inf 100-pctg_inf], 4); % Percentile bounds
out.IRinf = aux2(:, :, :, 1);               % Lower bound
out.IRsup = aux2(:, :, :, 2);               % Upper bound
out.accept_rate = sum(idx) / numel(idx);     % Share of Level 1 draws retained

VAR_fp      = VAR;  VAR_fp.B = out.Bfp;     % Attach Fry-Pagan B to VAR structure
[~, VAR_fp] = compute_wold(VAR_fp, VARopt); % Compute Wold (MA) representation
out.HDfp    = compute_HD(VAR_fp, out.Bfp);  % Historical decomposition for Fry-Pagan draw
end