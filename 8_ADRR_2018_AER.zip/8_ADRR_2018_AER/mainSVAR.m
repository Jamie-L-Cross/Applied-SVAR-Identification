% =======================================================================
% Partial replication of Antolin-Diaz & Rubio-Ramirez (2018, AER):
% "Narrative Sign Restrictions for SVARs"
%
% Identifies a contractionary monetary policy shock in a 6-variable VAR
% at two tiers of identification:
%
%   BASELINE   -- sign restrictions only (Uhlig 2005, Table 3):
%                 pi falls, comm falls, nbres falls, ff rises at h=0..5
%   NARRATIVE  -- sign + two narrative restrictions at October 1979:
%                 (1) Type 1: monetary policy shock is positive at t*
%                 (2) Type 2: monetary policy shock is the dominant driver of ff at t*
%
% Adding narrative evidence from the Volcker reform substantially tightens
% the identified set relative to sign restrictions alone.
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for standalone replication use, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all
rng(42)

% Toolbox root is two levels up from this file (.../VAR-Toolbox-main)
toolboxroot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(toolboxroot, 'VAR'));
addpath(fullfile(toolboxroot, 'Figure'));
addpath(fullfile(toolboxroot, 'Stats'));
addpath(fullfile(toolboxroot, 'Utils'));
addpath(fullfile(toolboxroot, 'Auxiliary'));
cd(fileparts(mfilename('fullpath')));

% Data and results folders
datafile = fullfile(toolboxroot, 'Replic', 'ADRR2018', 'ADRR2018_Data.xlsx');
resdir   = fullfile(fileparts(mfilename('fullpath')), 'results');
if ~exist(resdir, 'dir')
    mkdir(resdir);
end

%% 1. LOAD DATA
% -----------------------------------------------------------------------
% Spreadsheet layout: row 1 = long names, row 2 = mnemonics,
% rows 3+ = monthly observations with date labels in column 1.
% Variables:
% 1. y     (real GDP, log)
% 2. pi    (GDP deflator, log)
% 3. comm  (commodity prices, log)
% 4. res   (total reserves, log)
% 5. nbres (non-borrowed reserves, log)
% 6. ff    (federal funds rate, %)

% Load data
raw       = readcell(datafile, 'Sheet', 'Sheet1');
dates_str = raw(3:end, 1);                          % date strings for narrative period lookup
y         = cellfun(@double, raw(3:end, 2:end));

vnames = raw(1, 2:end);   % long variable names (for plot titles)
mnem   = raw(2, 2:end);   % short mnemonics
nvar   = length(mnem);    % kept for compatibility with figure sections below

% Details for DatesPlot
firstdate = 1965; % 1965:M1
nticks    = 6;
[T, n]    = size(y);

% Data plot
figure;
FigSize(22, 14)
for ii = 1:n
    subplot(3, 2, ii)
    plot(y(:, ii), 'LineWidth', 2, 'Color', pantone('Blue'))
    title(vnames{ii}, 'FontSize', 12)
    DatesPlot(firstdate, T, nticks, 'm')
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
end
SaveFigure(fullfile(resdir, 'Figure_1_Data'), 2)
disp('Figure 1 (data) saved.')

%% 2. Specify inputs
p      = 12;    % lag length (footnote 8, p.27)
detc   = 0;     % no constant (footnote 8, p.27)
hor    = 60;    % IRF horizon (months)
ndraws = 500;   % number of accepted impact matrix draws

% Sign restriction matrix: +1 positive, -1 negative, 0 unrestricted.
% Contractionary MP shock (col 1): Uhlig (2005) Table 3.
SIGN = [ 0, 0, 0, 0, 0, 0;  % y:     unrestricted (agnostic)
        -1, 0, 0, 0, 0, 0;  % pi:    falls
        -1, 0, 0, 0, 0, 0;  % comm:  falls
         0, 0, 0, 0, 0, 0;  % res:   unrestricted
        -1, 0, 0, 0, 0, 0;  % nbres: falls
         1, 0, 0, 0, 0, 0]; % ff:    rises

IRFrestrict = 6; % impose sign restrictions for 6 periods (h = 0,...,5)

%% 3. VAR ESTIMATION: SIGN RESTRICTIONS ONLY (BASELINE)
% -----------------------------------------------------------------------
VARopt        = VARoption;
VARopt.ident  = 'sign';      % Sign restrictions
VARopt.R      = SIGN;        % Sign restriction matrix
VARopt.sr_hor = IRFrestrict; % Impose restrictions for 6 months
VARopt.nsteps = hor;         % Impulse horizon
VARopt.ndraws = ndraws;      % Number of accepted draws
VARopt.inference = 1;        % Draw reduced-form using Bayes
VARopt.pctg = 68;            % 68% credible bands

SRout = VARmodel(y, p, detc, VARopt);
disp(['Sign only:  acceptance rate = ' num2str(100*SRout.accept_rate,'%.2f') '%'])

%% 4. VAR ESTIMATION: SIGN + NARRATIVE RESTRICTIONS
% -----------------------------------------------------------------------
% Two narrative restrictions at October 1979 (Volcker reform):
%   Type 1 (sign):      MP shock is positive at t* (e_{mp,t*} > 0)
%   Type 2 (dominance): MP shock is the dominant driver of ff at t*
R.sign         = SIGN;            % Use sign restrictions
R.narr_sign.shock  = 1;           % Narrative shock: monetary policy (col 1)
R.narr_sign.period = '1979m10';   % Narrative shock period: October 1979
R.narr_sign.sign   = 1;           % Narrative shock sign: positive (monetary contraction)
R.narr_dom.shock   = 1;           % Dominant shock: monetary policy (col 1)
R.narr_dom.period  = '1979m10';   % Dominant shock period: October 1979
R.narr_dom.var     = 6;           % Dominant shock main driver of FFR (var 6)

VARopt.R       = R;               % Combined sign + narrative restriction structure (see SR.m within VARmodel.m)
VARopt.dates   = dates_str;       % Date strings for narrative period lookup within identification
VARopt.sr_draw = ndraws*1000;     % Maxmimum number of checks for narrative restrictions before cancelling (rate is often low)

NSRout = VARmodel(y, p, detc, VARopt);
disp(['Sign+narrative: acceptance rate = ' num2str(100*NSRout.accept_rate,'%.2f') '%'])

%% 5. NORMALIZE IRFs TO 25bp IMPACT ON FED FUNDS RATE
% -----------------------------------------------------------------------
ff_var   = 6;   % fed funds rate
mp_shock = 1;   % monetary policy shock

% scale SR model
sc_SR  = 0.25 * 100 / median(squeeze(SRout.IRall( 1, ff_var, mp_shock, :))); 
aux = prctile(SRout.IRall  * sc_SR,  [16 50 84], 4);
IRinf_SR  = aux(:,:,:,1);  
IRmed_SR  = aux(:,:,:,2);  
IRsup_SR  = aux(:,:,:,3);

% scale narrative model
sc_NSR = 0.25 * 100 / median(squeeze(NSRout.IRall(1, ff_var, mp_shock, :))); 
aux = prctile(NSRout.IRall * sc_NSR, [16 50 84], 4);
IRinf_NSR = aux(:,:,:,1);  
IRmed_NSR = aux(:,:,:,2);  
IRsup_NSR = aux(:,:,:,3);

%% 6. FIGURE 2: IRF COMPARISON (replicates ADRR Fig. 6)
% -----------------------------------------------------------------------
steps = 0:hor-1; % Start x-axis at zero

figure; 
FigSize(22, 18)
for ii = 1:n
    subplot(3, 2, ii); hold on
    fill([steps fliplr(steps)], [IRinf_SR( :,ii,mp_shock)' fliplr(IRsup_SR( :,ii,mp_shock)')], pantone('Blue'),  'FaceAlpha', 0.15, 'EdgeColor', 'none')
    fill([steps fliplr(steps)], [IRinf_NSR(:,ii,mp_shock)' fliplr(IRsup_NSR(:,ii,mp_shock)')], pantone('Tomato'), 'FaceAlpha', 0.30, 'EdgeColor', 'none')
    h1 = plot(steps, IRmed_SR( :,ii,mp_shock), '-', 'Color', pantone('Blue'),  'LineWidth', 2);
    h2 = plot(steps, IRmed_NSR(:,ii,mp_shock), '-', 'Color', pantone('Tomato'), 'LineWidth', 2);
    plot([steps(1) steps(end)], [0 0], '-k', 'LineWidth', 0.5)
    xlim([steps(1) steps(end)])
    title(vnames{ii}, 'FontSize', 12)
    if ii == n
        legend([h1 h2], {'Sign only', 'Sign + Narrative'}, 'Location', 'best')
    end
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
end
SaveFigure(fullfile(resdir, 'Figure_2_IRFs'), 2)
disp('Figure 2 (IRF comparison) saved.')

%% 7. FIGURE 3: SHOCK DISTRIBUTION AT OCTOBER 1979 (replicates ADRR Fig. 5)
% -----------------------------------------------------------------------
% Distribution of the MP shock at t* across accepted draws.
% Narrative restrictions concentrate mass to the right of zero.

% 1979m10 is observation 178 in the full sample -> 178 - 12 = 166 in the residuals matrix
t_narr = find(strcmp(dates_str, '1979m10')) - p;

% Sign restriction shocks
shocks_SR  = zeros(size(SRout.Ball,  3), 1);
for dd = 1:size(shocks_SR,1)
    e = SRout.Ball(:,:,dd) \ SRout.resid';
    shocks_SR(dd)  = e(mp_shock, t_narr);
end

% Narrative restriction shocks
shocks_NSR = zeros(size(NSRout.Ball, 3), 1);
for dd = 1:size(shocks_NSR,1)
    e = NSRout.Ball(:,:,dd) \ NSRout.resid';
    shocks_NSR(dd) = e(mp_shock, t_narr);
end

% Plot
figure; 
FigSize(14, 8)
histogram(shocks_SR,  30, 'FaceColor', pantone('Blue'),  'FaceAlpha', 0.5, 'EdgeColor', 'white')
hold on
    histogram(shocks_NSR, 30, 'FaceColor', pantone('Tomato'), 'FaceAlpha', 0.5, 'EdgeColor', 'white')
hold off
xline(0, '--k', 'LineWidth', 0.5)
title('Shock distribution at October 1979 (Volcker reform)', 'FontSize', 12)
xlabel('Monetary policy shock at October 1979')
ylabel('Count')
legend({'Sign only', 'Sign + Narrative'}, 'Location', 'best')
set(gca, 'FontSize', 11)
grid on
SetAxesDual(gca)
SaveFigure(fullfile(resdir, 'Figure_3_ShockDist'), 2)
disp('Figure 3 (shock distribution) saved.')

disp('=== ADRR (2018) replication complete ===')