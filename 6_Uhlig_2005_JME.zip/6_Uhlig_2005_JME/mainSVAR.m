% =======================================================================
% Partial replication of Uhlig (2005, JME):
% "What are the Effects of Monetary Policy on Output?
%  Results from an Agnostic Identification Procedure"
%
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for standalone replication use, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all
rng(42)

% Toolbox root is two levels up from this file (.../VAR-Toolbox-main)
toolboxroot = fileparts(fileparts(fileparts(mfilename('fullpath'))));
addpath(fullfile(toolboxroot, 'VAR'));
addpath(fullfile(toolboxroot, 'Figure'));
addpath(fullfile(toolboxroot, 'Stats'));
addpath(fullfile(toolboxroot, 'Utils'));
addpath(fullfile(toolboxroot, 'Auxiliary'));
cd(fileparts(mfilename('fullpath')));

% Data and results folders
datafile = fullfile(toolboxroot, 'Replic', 'Uhlig2005', 'Uhlig2005_Data.xlsx');
resdir   = fullfile(fileparts(mfilename('fullpath')), 'results');
if ~exist(resdir, 'dir')
    mkdir(resdir); 
end

%% 1. LOAD DATA
% -----------------------------------------------------------------------
% Spreadsheet layout: row 1 = long names, row 2 = mnemonics,
% rows 3+ = monthly observations with date labels in column 1.
% Variables: 
% 1. y (IP, log)
% 2. pi (deflator, log)
% 3. comm (commodity price, log)
% 4. res (total reserves, log)
% 5. nbres (non-borrowed res., log)
% 6. ff (federal funds rate, %)

% Load data
raw  = readcell(datafile, 'Sheet', 'Sheet1');
data = cellfun(@double, raw(3:end, 2:end));
data(:, 1:5) = 100 * data(:, 1:5); % rescale log-level variables by 100 to express in percent
y = data;

vnames = raw(1, 2:end);   % long variable names (for plot titles)
mnem   = raw(2, 2:end);   % short mnemonics
nvar   = length(mnem);    % kept for compatibility with figure sections below

% Details for DatesPlot
firstdate = 1965; % 1964:M1
nticks    = 6;
[T, n]    = size(y);

% Data plot
figure;
FigSize(22, 14)
for ii = 1:n
    subplot(3, 2, ii)
    plot(y(:, ii), 'LineWidth', 2, 'Color', pantone('Blue'))
    title(vnames{ii}, 'FontSize', 12)
    DatesPlot(firstdate, T, nticks, 'm')
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
end
SaveFigure(fullfile(resdir, 'Figure_1_Data'), 2)
disp('Figure 1 (data) saved.')

%% 2. Specify inputs
p      = 12;    % lag length (Uhlig 2005)
detc   = 1;     % constant
hor    = 60;    % IRF horizon (months)
ndraws = 500;   % number of accepted impact matrix draws

% Sign restriction matrix: +1 positive, -1 negative, 0 unrestricted.
% Only column 1 is restricted (MP shock). The rest are reduced form.
SIGN = [ 0, 0, 0, 0, 0, 0;  % Industrial production (unrestricted -- agnostic)
        -1, 0, 0, 0, 0, 0;  % GDP deflator
        -1, 0, 0, 0, 0, 0;  % Commodity price
         0, 0, 0, 0, 0, 0;  % Total reserves (unrestricted)
        -1, 0, 0, 0, 0, 0;  % Non-borrowed reserves
         1, 0, 0, 0, 0, 0]; % Federal funds rate

IRFrestrict = 6; % Restrict IRF signs for 6 periods too

%% 3. VAR ESTIMATION WITH SIGN RESTRICTIONS
% -----------------------------------------------------------------------
VARopt        = VARoption;
VARopt.ident  = 'sign'; % Sign restrictions
VARopt.R      = SIGN;   % Sign matrix
VARopt.sr_hor = IRFrestrict; % Impose restrictions for 6 months
VARopt.nsteps = hor;    % Impulse horizon
VARopt.ndraws = ndraws; % Number of draws of admissible restrictions
VARopt.inference = 1;   % Draw reduced-form using Bayes for replication figure
VARopt.pctg = 68;       % Credible set coverage for replication figure

SRout = VARmodel(y, p, detc, VARopt);
disp('VAR with sign restrictions estimated.')

%% 4. PLOT INDIVIDUAL DRAWS
% -----------------------------------------------------------------------
% Pre-compute ylim range from all accepted draws (shock 1 = MP shock).
% Used to share axis limits across the next few figures
store = zeros(nvar, 2);
for ii = 1:nvar
    vals = SRout.IRall(:, ii, 1, :);
    store(ii, :) = [min(vals(:)), max(vals(:))];
end

% Plot first draw
figure;
FigSize(24, 12)
for ii = 1:nvar
    subplot(2, 3, ii)
    plot(SRout.IRall(:, ii, 1, 1)); hold on
    plot(zeros(VARopt.nsteps), '-k');
    title(vnames{ii}, 'FontSize', 12);
    ylim(store(ii, :))
    set(gca, 'FontSize', 11);
    grid on
    SetAxesDual(gca);
end
SaveFigure(fullfile(resdir, 'Figure_2_IRFs_ONE'))

% Plot second draw
figure;
FigSize(24, 12)
for ii = 1:nvar
    subplot(2, 3, ii)
    plot(SRout.IRall(:, ii, 1, 1));
    hold on
        plot(SRout.IRall(:, ii, 1, 2));
        plot(zeros(VARopt.nsteps), '-k');
    hold off
    title(vnames{ii}, 'FontSize', 12);
    ylim(store(ii, :))
    set(gca, 'FontSize', 11);
    grid on
    SetAxesDual(gca);
end
SaveFigure(fullfile(resdir, 'Figure_3_IRFs_TWO'))

% Plot all draws
figure;
FigSize(24, 12)
for ii = 1:nvar
    subplot(2, 3, ii)
    plot(squeeze(SRout.IRall(:, ii, 1, :))); 
    hold on
    plot(zeros(VARopt.nsteps), '-k'); 
    hold off
    title(vnames{ii}, 'FontSize', 12);
    set(gca, 'FontSize', 11);
    grid on
    SetAxesDual(gca);
end
SaveFigure(fullfile(resdir, 'Figure_4_IRFs_ALL'))

%% 7. FIGURE 2 -- REPLICATION OF UHLIG (2005) FIGURE 6
% -----------------------------------------------------------------------
% The paper plots: left col = y, pi, comm; right col = res, nbres, ff 
% VARirplot fills subplots row-first, so requires reordering
ord = [1, 4, 2, 5, 3, 6]; % Changed order
VARopt.vnames  = vnames(ord); % Update the names
VARopt.figsize = [24, 18]; % Figure size
VARopt.subplot = [3, 2]; % Subplot
VARopt.pick    = 1;
VARopt.figname = fullfile(resdir, 'Figure_5_Uhlig_IRFs');
VARirplot(SRout.IRmed(:,ord,:), VARopt, SRout.IRinf(:,ord,:), SRout.IRsup(:,ord,:))

%% 8. FIGURE: MEDIAN IRF vs FRY-PAGAN MEDIAN IRF
% -----------------------------------------------------------------------
% The median IRF is the element-wise median across all accepted draws.
% It is not implied by any single structural model (Fry and Pagan, 2011).
% The Fry-Pagan IRF comes from the accepted draw whose impact matrix is
% closest (Frobenius distance) to the median, and therefore a valid SVAR.

col_med = pantone('Blue');   % naive median
col_fp  = pantone('Tomato'); % Fry-Pagan median target

steps = 0:hor-1;

figure; FigSize(22, 14)
for ii = 1:n
    subplot(3, 2, ii)
    h1 = plot(steps, SRout.IRmed(:, ii, 1), '-',  'Color', col_med, 'LineWidth', 2); hold on
    h2 = plot(steps, SRout.IRfp( :, ii, 1), '--', 'Color', col_fp,  'LineWidth', 2);
    plot([steps(1) steps(end)], [0 0], '-k', 'LineWidth', 0.5)
    title(vnames{ii}, 'FontSize', 12)
    if ii == 1
        legend([h1 h2], {'Median IRF', 'Fry-Pagan Median IRF'}, ...
            'FontSize', 9, 'Location', 'best')
    end
    set(gca, 'FontSize', 11)
    grid on
    SetAxesDual(gca)
end
set(findall(gcf, '-property', 'FontName'), 'FontName', 'Palatino')
SaveFigure(fullfile(resdir, 'Figure_6_Median_vs_FryPagan'), 2)

disp('=== Uhlig (2005) replication complete ===')

