% Forecast_VAR.m
% =======================================================================
% Stock and Watson (2001, JEP), "Vector Autoregressions"
% Replication of Table 2: Pseudo Out-of-Sample Forecast RMSEs.
%
% EXERCISE
%   For each forecast origin from 1985:Q1 to 2000:Q4, re-estimate three
%   models on all available history and forecast h quarters ahead:
%     RW  -- Random Walk (current level persists).
%     AR  -- Univariate AR(4), one equation per variable.
%     VAR -- Trivariate VAR(4) in [Inflation, Unemployment, Fed Funds Rate].
%
% FORECAST TARGETS (SW Table 2 footnote)
%   Inflation      -- average over the h-quarter forecast window.
%   Unemployment   -- value at the final quarter of the window.
%   Fed Funds Rate -- value at the final quarter of the window.
%
% HELPERS
%   arForecast  -- OLS AR(p) estimated via VARmakexy, iterated h steps.
%   varForecast -- OLS VAR(p) estimated via VARmakexy, iterated h steps.
%   Both functions are defined at the bottom of this file.
%
% NOTE
%   Minor discrepancies from the published numbers are expected due to
%   data revisions since the 2001 vintage used by SW (see Estimate_VAR.m).
% =======================================================================
% VAR Toolbox 4.0 -- Ambrogio Cesa-Bianchi
% Adapted for Applications folder, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all

%% 0. PATHS
thisFile    = mfilename('fullpath');
appRoot     = fileparts(thisFile);
toolboxRoot = fileparts(fileparts(appRoot));
addpath(genpath(fullfile(toolboxRoot, 'VAR')));
addpath(genpath(fullfile(toolboxRoot, 'Stats')));

dataFile = fullfile(toolboxRoot, 'Replic', 'SW2001', 'SW2001_Data.xlsx');
resdir   = fullfile(appRoot, 'results');
if ~exist(resdir, 'dir'); mkdir(resdir); end

%% 1. LOAD DATA
% 1960:Q1 to 2000:Q4 -- 164 quarterly observations.
% Columns: [1] Inflation (pi), [2] Unemployment (u), [3] Fed Funds Rate (R)
raw    = readcell(dataFile, 'Sheet', 'Sheet1');
data   = cellfun(@double, raw(3:end, 2:end));
vnames = raw(1, 2:end);
nobs   = size(data, 1);           % 164
nvar   = size(data, 2);           % 3

VAR_INFL  = 1;
VAR_UNEMP = 2;
VAR_FF    = 3;

%% 2. FORECAST PARAMETERS
% Forecast origins: 1985:Q1 (obs 101) to 2000:Q4 (obs 164), 64 per horizon.
nlags    = 4;
fc_start = (1985 - 1960)*4 + 1;       % = 101
n_fc     = nobs - fc_start + 1;       % = 64
horizons = [2, 4, 8];
nh       = length(horizons);

% Helper: return the right point forecast depending on the variable.
%   Inflation -- average over all h forecast steps.
%   Others    -- value at the final step only.
fcTgt = @(yf, isInfl) isInfl * mean(yf) + ~isInfl * yf(end);

% RMSE(hh, vv, mm): horizon hh, variable vv, model mm = {1=RW, 2=AR, 3=VAR}
RMSE = zeros(nh, nvar, 3);

%% 3. RECURSIVE FORECASTING LOOP
% At each origin t, estimate on data(1:t,:) and forecast h steps ahead.
% All OLS estimation and multi-step iteration is handled by the two local
% functions arForecast and varForecast defined at the bottom of this file.

for hh = 1:nh
    h = horizons(hh);
    err = zeros(n_fc, nvar, 3);   % forecast errors: [origin, variable, model]

    fprintf('Horizon %d quarters ...', h)

    for tt = 1:n_fc
        T = fc_start + tt - 1;   % last quarter of the forecast window
        t = T - h;               % forecast origin (estimate on data 1 to t)

        % Realised values
        actual = [mean(data(t+1:t+h, VAR_INFL));  % inflation: h-quarter average
                  data(t+h, VAR_UNEMP);           % unemployment: final quarter
                  data(t+h, VAR_FF)];             % FFR: final quarter

        % Random Walk -- forecast is simply the current level
        err(tt, :, 1) = data(t, :) - actual';

        % AR(4) -- one equation per variable, re-estimated each origin
        for vv = 1:nvar
            yf = arForecast(data(1:t, vv), h, nlags);
            err(tt, vv, 2) = fcTgt(yf, vv == VAR_INFL) - actual(vv);
        end

        % VAR(4) -- trivariate system, re-estimated each origin
        Y_fc = varForecast(data(1:t, :), h, nlags);
        fc   = [fcTgt(Y_fc(:, VAR_INFL),  true );
                fcTgt(Y_fc(:, VAR_UNEMP), false);
                fcTgt(Y_fc(:, VAR_FF),    false)];
        err(tt, :, 3) = (fc - actual)';
    end

    RMSE(hh, :, :) = reshape(sqrt(mean(err.^2, 1)), nvar, 3);
    fprintf(' done.\n')
end

%% 4. PRINT TABLE 2
fprintf('\n');
fprintf('Table 2: RMSE of Simulated Out-of-Sample Forecasts, 1985:I--2000:IV\n');
fprintf('%-14s  %-26s  %-26s  %-26s\n', '', vnames{1}, vnames{2}, vnames{3});
fprintf('%-14s  %8s %8s %8s  %8s %8s %8s  %8s %8s %8s\n', ...
        'Horizon', 'RW','AR','VAR', 'RW','AR','VAR', 'RW','AR','VAR');
fprintf('%s\n', repmat('-', 1, 94));
hlabels = {'2 quarters', '4 quarters', '8 quarters'};
for hh = 1:nh
    fprintf('%-14s  %8.2f %8.2f %8.2f  %8.2f %8.2f %8.2f  %8.2f %8.2f %8.2f\n', ...
            hlabels{hh}, ...
            RMSE(hh,1,1), RMSE(hh,1,2), RMSE(hh,1,3), ...
            RMSE(hh,2,1), RMSE(hh,2,2), RMSE(hh,2,3), ...
            RMSE(hh,3,1), RMSE(hh,3,2), RMSE(hh,3,3));
end

%% 5. SAVE TABLE 2 TO CSV
T_out    = cell(nh + 2, 1 + nvar*3);
T_out(1, :) = [{'Horizon'}, repmat(vnames(1),1,3), repmat(vnames(2),1,3), repmat(vnames(3),1,3)];
T_out(2, :) = [{''},        {'RW','AR','VAR'},      {'RW','AR','VAR'},      {'RW','AR','VAR'}];
for hh = 1:nh
    T_out{hh+2, 1} = hlabels{hh};
    for vv = 1:nvar
        for mm = 1:3
            T_out{hh+2, 1+(vv-1)*3+mm} = round(RMSE(hh,vv,mm), 2);
        end
    end
end
writecell(T_out, fullfile(resdir, 'Table2_RMSE.csv'));
disp('Table 2 saved to results/Table2_RMSE.csv')
disp('=== Stock and Watson (2001) forecast replication complete ===')

% =======================================================================
%  LOCAL FUNCTIONS  (require MATLAB R2016b or later)
% =======================================================================

function yf = arForecast(y, h, nlags)
% arForecast  OLS AR(nlags) estimated on y; iterate h steps ahead.
%
%   [Y, X] = VARmakexy(y, nlags, 1) builds the regression in one call.
%   The state vector [1, y_t, y_{t-1}, ..., y_{t-p+1}] is then shifted
%   forward h times using the OLS coefficients.
%
%   Returns yf: (h x 1) forecast path (step 1 through step h).
    [Y, X] = VARmakexy(y, nlags, 1);
    b  = X \ Y;                                      % OLS: [1+nlags x 1]
    st = [1, y(end:-1:end-nlags+1)'];               % initial state (row)
    yf = zeros(h, 1);
    for s = 1:h
        yn    = st * b;                              % one-step forecast
        yf(s) = yn;
        st    = [1, yn, st(2:end-1)];               % shift state forward
    end
end


function Yf = varForecast(Y, h, nlags)
% varForecast  OLS VAR(nlags) estimated on Y; iterate h steps ahead.
%
%   Uses VARmakexy to build the stacked regressor matrix, then iterates
%   the companion-form state [1, y_t, y_{t-1}, ..., y_{t-p+1}] forward
%   h times.
%
%   Returns Yf: (h x nvar) forecast path (step 1 through step h).
    nvar     = size(Y, 2);
    [Ym, Xm] = VARmakexy(Y, nlags, 1);
    Ft       = Xm \ Ym;                             % OLS: [(1+nvar*nlags) x nvar]
    st       = [1, reshape(Y(end:-1:end-nlags+1,:)', 1, [])];  % initial state
    Yf       = zeros(h, nvar);
    for s = 1:h
        yn      = st * Ft;                           % one-step forecast (1 x nvar)
        Yf(s,:) = yn;
        st      = [1, yn, st(2:end-nvar)];          % shift state forward
    end
end