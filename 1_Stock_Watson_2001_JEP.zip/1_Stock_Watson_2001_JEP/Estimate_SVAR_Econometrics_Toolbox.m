% Estimate_SVAR_Econometrics_Toolbox.m
% =======================================================================
% Stock and Watson (2001, JEP), "Vector Autoregressions"
% Replication using MATLAB's Econometrics Toolbox.
%
% MODEL
%   3-variable quarterly VAR, 4 lags, constant.
%   Ordering (Cholesky): [Inflation, Unemployment, Fed Funds Rate].
%
% TOOLBOX FUNCTIONS USED
%   varm, estimate  -- reduced-form VAR estimation
%   gctest          -- Granger causality tests
%   infer           -- extract VAR residuals for bootstrap
%   irf             -- orthogonalized (Cholesky) impulse responses with
%                      68% residual-bootstrap confidence bands
%   fevd            -- forecast error variance decomposition
%   filter          -- causal FIR convolution for historical decomposition
%   Figures use standard MATLAB plotting only (no ACB toolbox needed).
%
% OUTPUTS (figures saved with _EconToolbox suffix for easy comparison)
%   Figure 1: Data plot.
%   Figure 2: IRF with 68% bootstrap band - Replicates SW (2001) Figure 1.
%   Figure 3: FEVD bar chart at horizons 1,4,8,12 quarters.
%   Figure 4: Historical decomposition of all three variables.
%   Table 1A: Granger causality p-values - Replicates SW (2001) Table 1A.
%   Table 1B: FEVD at horizons 1,4,8,12  - Replicates SW (2001) Table 1B.
% =======================================================================
% Adapted for Applications folder, June 2026
% -----------------------------------------------------------------------

clear; close all; clc
warning off all

%% 0. PATHS
% -----------------------------------------------------------------------
thisFile    = mfilename('fullpath');
appRoot     = fileparts(thisFile);
toolboxRoot = fileparts(fileparts(appRoot));
dataFile    = fullfile(toolboxRoot, 'Replic', 'SW2001', 'SW2001_Data.xlsx');
resdir      = fullfile(appRoot, 'results');
if ~exist(resdir, 'dir'); mkdir(resdir); end


%% 1. LOAD DATA
% -----------------------------------------------------------------------
raw    = readcell(dataFile, 'Sheet', 'Sheet1');
X      = cellfun(@double, raw(3:end, 2:end));
vnames = raw(1, 2:end);
mnem   = raw(2, 2:end);
nvar   = length(mnem);
nobs   = size(X, 1);
nlags  = 4;
nsteps = 24;

%% 2. FIGURE 1 -- DATA PLOT
% -----------------------------------------------------------------------
% First observation year+quarter for x-axis labels
year0    = str2double(raw{3,1}(1:4));
quarter0 = str2double(raw{3,1}(6));
tvec     = year0 + ((quarter0-1) + (0:nobs-1)') / 4;   % decimal year

% Figure
col_blue = [0.20, 0.40, 0.75];
fig1 = figure('Name', 'Data');
set(fig1, 'Position', [100, 100, 700, 600]);
for ii = 1:nvar
    subplot(1, 3, ii)
    plot(tvec, X(:, ii), '-', 'Color', col_blue, 'LineWidth', 1.8);
    title(vnames{ii}, 'FontSize', 11, 'FontWeight', 'bold');
    xlabel('Year'); grid on;
    set(gca, 'FontSize', 10);
end
saveas(fig1, fullfile(resdir, 'Figure1_Data_EconToolbox.png'));
disp('Figure 1 (data) saved.')


%% 3. ESTIMATE VAR  (varm / estimate)
% -----------------------------------------------------------------------
Mdl             = varm(nvar, nlags);
Mdl.SeriesNames = mnem;
EstMdl          = estimate(Mdl, X, 'Display', 'off');

fprintf('\nVAR(%d) estimated: %d observations, %d variables.\n', nlags, nobs, nvar);


%% 4. TABLE 1A -- GRANGER CAUSALITY  (gctest)
% -----------------------------------------------------------------------
% gctest tests cross-variable pairs only (n*(n-1) = 6 tests for n=3).
% Diagonal (self-Granger-causality) is not covered by gctest.
fprintf('\nTable 1A: Granger Causality Tests\n');
fprintf('(gctest covers cross-variable pairs; diagonal excluded)\n');
gc_tbl = gctest(EstMdl);
disp(gc_tbl)

%% 5. STRUCTURAL IRF WITH 90% CONFIDENCE BANDS  (Cholesky, via built-in irf)
% -----------------------------------------------------------------------
% Passing E=Res triggers residual-bootstrap across NumPaths draws.
% IRF(t, response_i, shock_j): index directly as IRF(:, cc, rr).
Res = infer(EstMdl, X);
rng(42, 'twister')
[IRF, IRF_lo, IRF_hi] = irf(EstMdl, 'E', Res, ...
    'NumPaths', 500, 'Confidence', 0.68, 'NumObs', nsteps + 1);


%% 6. FIGURE 2 -- IRF GRID
% -----------------------------------------------------------------------
lags         = 0:nsteps;
shock_labels = {'Inflation Shock', 'Unemployment Shock', 'Int. Rate Shock'};

fig2 = figure('Name', 'IRF Grid -- Econometrics Toolbox');
set(fig2, 'Position', [100, 100, 900, 650]);
for rr = 1:nvar          % row = shock
    for cc = 1:nvar      % col = response variable
        subplot(nvar, nvar, (rr-1)*nvar + cc);
        plot(lags, IRF(:, cc, rr),    '-',  'Color', col_blue, 'LineWidth', 2); hold on
        plot(lags, IRF_lo(:, cc, rr), '--', 'Color', col_blue, 'LineWidth', 0.8);
        plot(lags, IRF_hi(:, cc, rr), '--', 'Color', col_blue, 'LineWidth', 0.8);
        yline(0, 'k');
        xlim([0, nsteps]); grid on; set(gca, 'FontSize', 9);
        if rr == 1 
            title(vnames{cc}, 'FontSize', 10, 'FontWeight', 'bold'); 
        end
        if cc == 1
            ylabel(shock_labels{rr}, 'FontSize', 9); 
        end
        if rr == nvar
            xlabel('Lag (quarters)', 'FontSize', 9); 
        end
    end
end
sgtitle('Impulse Responses -- Econometrics Toolbox (Cholesky, 90% CI)', ...
        'FontSize', 11, 'FontWeight', 'bold');
saveas(fig2, fullfile(resdir, 'Figure2_IRF_EconToolbox.png'));
disp('Figure 2 (IRF grid with 90% CI) saved.')


%% 7. FEVD  (built-in fevd)
% -----------------------------------------------------------------------
Decomposition = fevd(EstMdl, 'NumObs', nsteps + 1);   % (h, shock, response)

%% 8. TABLE 1B -- VARIANCE DECOMPOSITION
% -----------------------------------------------------------------------
horizons = [1, 4, 8, 12];

fprintf('\nTable 1B: Forecast Error Variance Decomposition (percent)\n');
for i = 1:nvar
    fprintf('\nVariance Decomposition of %s:\n', vnames{i});
    fprintf('%-10s  %10s  %10s  %10s\n', 'Horizon', mnem{:});
    fprintf('%s\n', repmat('-', 1, 44));
    for h = horizons
        fprintf('%-10d  %10.0f  %10.0f  %10.0f\n', h, Decomposition(h, :, i) * 100);
    end
end

%% 9. FIGURE 3 -- FEVD BAR CHART
% -----------------------------------------------------------------------
h_plot = [1, 4, 8, 12, 24];

fig3 = figure('Name', 'FEVD -- Econometrics Toolbox');
set(fig3, 'Position', [100, 100, 950, 320]);
for i = 1:nvar
    subplot(1, nvar, i)
    fevd_h = Decomposition(h_plot, :, i);           % [length(h_plot) x nvar]
    bar(fevd_h, 'stacked');
    xticks(1:length(h_plot));
    xticklabels(arrayfun(@num2str, h_plot, 'UniformOutput', false));
    xlabel('Horizon (quarters)'); ylabel('Fraction');
    title(vnames{i}, 'FontSize', 10, 'FontWeight', 'bold');
    if i == nvar
        legend(mnem, 'Location', 'eastoutside', 'FontSize', 9);
    end
    grid on; ylim([0, 1]);
end
sgtitle('FEVD -- Econometrics Toolbox (Cholesky)', ...
        'FontSize', 11, 'FontWeight', 'bold');
saveas(fig3, fullfile(resdir, 'Figure3_FEVD_EconToolbox.png'));
disp('Figure 3 (FEVD bar chart) saved.')

%% 10. FIGURE 4 -- HISTORICAL DECOMPOSITION
% -----------------------------------------------------------------------
% The Econometrics Toolbox has no built-in HD. Need to code manually. Or
% use the ACB Toolbox!